window.onload = function(){
	var bodyWidth = document.body.clientWidth;
	var size = 36/750*bodyWidth + "px";
	document.getElementsByTagName('html')[0].style.fontSize=size;
}
